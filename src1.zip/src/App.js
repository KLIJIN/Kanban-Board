import './App.css';
// import Card from './components/card/Card'
// import Panel from './components/Panel/Panel'
import Panels from "./containers/Panels"
//import Counter from "./Counter"
//import {connect} from "react-redux" //вставка из минина

function App() {
  // debugger;
  return (
    <div className="app">
      <Panels 
      // items={
      //   [
      //     {text: "Пройти курс по Реакт"},
      //     {text: "Отметить день рождения" }
      //   ]
      // }
      />

    </div>
  );
}





export default App;
