import React from 'react'
import Card from "../card/Card"
import AddForm from "../AddForm/AddForm"
import clearSvg from "../../assets/clear.svg";
import "./Panel.scss"

//компонентная панель отрисовывает ЗАГОЛОВКИ И КАРТОЧКИ
const Panel = (  {columnIndex, title, cards, addColumn, AddCards, removeColumn} ) => {
    // console.log( "Panel777", AddPanel, AddCards);
    //  console.log("Panel777", panelIndex)
   // console.log("Panel_title", title);
    // console.log("Panel_cards",cards.cards);
    //   console.log("App_Panel_Panel", addColumn);
    //   console.log("App_Panel_Panel", removeColumn);

    return <div className= {`panel${!cards ? " panel--empty":"" }`}>
                
                    <div className="panel__title" >  
                        <b> {title} </b>
                       { cards && <div  className="column__remove" onClick={ () => removeColumn(columnIndex) } > 
                                <img src={clearSvg} alt="Clear svg icon" />
                        </div> }
                    </div>
               
                    <div className="pandel__items" >
                        {cards &&
                           cards.map( (card, index) => {
                                console.log("Panel_pandel__items",card)
                                return (
                                            <Card key={index}>
                                                {card} 
                                            </Card>
                                        ) 
                                })
                        }
                    </div>
                   
                <AddForm isEmptyPanel={cards} addColumn={addColumn} onAddCards={AddCards} columnIndex={columnIndex} />

            </div>
   
}

  export default Panel;