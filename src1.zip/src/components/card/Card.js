import React from 'react'
// import PropTypes from "prop-types";
import "./card.scss"

const Card = ({children}) => {
    return(
        <div className="Card">
            {children}
        </div>
    );
}

export default Card;


  // // используем PropTypes что-бы установить тип пропсов
  // Card.propTypes  = {
  //   children: PropTypes.oneOfType([PropTypes.node, PropTypes.string]).isRequired
  // };
