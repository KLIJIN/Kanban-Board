import React from "react";
import {connect} from "react-redux";  //The connect() function connects a React component to a Redux store.
import Panel from "../components/Panel/Panel.js"
import {addColumn, addCard, removeColumn} from "../reducers/actions.js"
//import { createDndContext } from "react-dnd";

//эта хуйня создается для того что бы Панель получила в пропсы все значения из стора

//ОБЕРТКА ДЛЯ ПАНЕЛИ ПЕРЕДАЕТ ПРОПСЫ ИЗ РЕДАКСА
const Panels = ({Columns, addColumn, addCard, removeColumn }) => {
    // console.log("App__Panels__props", Panels)
    // console.log("App__Panels__props",  addPanel, addCard)
   
    return (
        <section style={{display: "flex"}}>
                {Columns.map( ( item, index )   => {
                    return (
                            <Panel key={index}{...item} columnIndex={index} addColumn={addColumn} AddCards={addCard}  removeColumn={removeColumn} /> 
                            )
                })}
            <Panel addColumn={addColumn} AddCards={addCard}  removeColumn={removeColumn}    /> 
        </section>
    )
}

function mapStateToProps(state) {
    console.log("App__Panels_mapStateToProps", state)
    return {
        Columns: state.Column
    }
  }

//   const mapDispatchToProps = {
//     addPanel: addPanel,
//     addCard: addCard
//   }

//   const mapDispatchToProps = dispatch => {
//     return   { 
//             addPanel: () =>  dispatch( {  type: "PANELS:ADD"}),
//             addCard: () => dispatch(addCard)
//             }
//     }   

          // const mapDispatchToProps = dispatch => ({
        //     addPanel: (name) => dispatch( addPanel(name) ),
        //     addCard: (panelIndex, text) => dispatch( addCard(panelIndex, text) )
        // })

    const mapDispatchToProps = dispatch => ({

        addColumn: (name) => {
            dispatch(
                addColumn(name)
            )
          },

          removeColumn: (index) => {
            dispatch(
                removeColumn(index)
            )
          },
        
        addCard: (columnIndex, text) => {
            dispatch(
                addCard(columnIndex, text)
            )
          }
        }
        )

  export default connect (mapStateToProps, mapDispatchToProps) (Panels); 





//export default connect(({panels}) => panels) (Panels)

