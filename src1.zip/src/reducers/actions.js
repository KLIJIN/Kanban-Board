 
  export let addColumn =  (name) => (
        {
            type: "COLUMNS:ADD",
            payload: name
        }
    )

    export let removeColumn =  (index) => (
        {
            type: "COLUMNS:REMOVE",
            payload: index
        }
    )

    export let addCard =  (columnIndex, text) => (
        {
            type: "CARDS:ADD",
            payload: {
                columnIndex,
                text
            }
        }
    )